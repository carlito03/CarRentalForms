for proper functionality:
ADDED A DATABSE FILES database1.mdf and database1_log SO THE USER CAN DROP THE DATABASE IN THE DEFAULT FOLDER WHICH IS:

c:/databases/

database is called Database1